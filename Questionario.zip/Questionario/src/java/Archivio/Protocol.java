package Archivio;

public enum Protocol {
    SMTP,
    SMTPS,
    TLS
}
