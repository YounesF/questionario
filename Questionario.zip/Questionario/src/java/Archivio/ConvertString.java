package Archivio;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConvertString {
    public static Date convertStringToDate(String dataString){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        try {
            date = df.parse(dataString);
        } catch (ParseException ex) {
            Logger.getLogger(ConvertString.class.getName()).log(Level.SEVERE, null, ex);
        }
        return date;
    }
}
