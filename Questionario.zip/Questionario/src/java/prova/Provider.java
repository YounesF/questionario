package prova;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sala.stefano
 */
public interface Provider {
    String name = "iovbwnfi";
    String pwd = "5nodVLhOz0f_vqPZgzOh1_AAYmmssPq3";
    String connURL = "jdbc:postgresql://dumbo.db.elephantsql.com:5432/iovbwnfi";
}
