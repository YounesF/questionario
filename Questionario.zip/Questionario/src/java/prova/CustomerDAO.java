    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;
import java.sql.*;
/**
 *
 * @author sala.stefano
 */
public class CustomerDAO {
    
    static Connection conn;
    static PreparedStatement pst;
    
    public static int insertCustomer(CustomerBean u){
        int stato = 0;
        
        try{
            System.out.println(2);
            conn = ConnectionProvider.getCon();
            pst = conn.prepareStatement("insert into utente value(?,?)");
            pst.setString(1, u.getNome());
            pst.setString(2, u.getCognome());
            stato = pst.executeUpdate();
            conn.close();   
            System.out.println(3);
        }
        
        catch(Exception e){
            System.out.println(e);
        }
        return stato;
    }
}
