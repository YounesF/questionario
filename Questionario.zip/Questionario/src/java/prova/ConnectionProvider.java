/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prova;
import java.sql.*;
/**
 *
 * @author sala.stefano
 */
public class ConnectionProvider implements Provider{
    static Connection conn = null;
    
    static public Connection getCon(){
        try{
            Class.forName("org.postgresql.Driver");
            System.out.println(1);
            conn = DriverManager.getConnection(connURL, name, pwd);
        }
        catch(Exception e){
            System.out.println(e);
        }
        
        return conn;
    }
}
